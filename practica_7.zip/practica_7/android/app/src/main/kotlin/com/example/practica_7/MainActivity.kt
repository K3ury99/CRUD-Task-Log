package com.example.practica_7

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
